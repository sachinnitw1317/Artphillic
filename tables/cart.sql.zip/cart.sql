-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 18, 2015 at 09:58 AM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `cart`
--

-- --------------------------------------------------------

--
-- Table structure for table `all_groups`
--

CREATE TABLE IF NOT EXISTS `all_groups` (
  `gid` int(11) NOT NULL,
  `gname` varchar(100) NOT NULL,
  `num` int(11) NOT NULL,
  `pic` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `all_groups`
--

INSERT INTO `all_groups` (`gid`, `gname`, `num`, `pic`) VALUES
(1, 'sdsdgf', 2, 'shubham.jp'),
(2, 'knj', 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `city`
--

CREATE TABLE IF NOT EXISTS `city` (
  `ctid` int(11) NOT NULL,
  `cid` int(11) DEFAULT NULL,
  `sid` int(11) DEFAULT NULL,
  `ctname` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `city`
--

INSERT INTO `city` (`ctid`, `cid`, `sid`, `ctname`) VALUES
(1, 123, 1, 'Bamboo Flat'),
(2, 123, 1, 'Garacharma'),
(3, 123, 1, 'Port Blair'),
(4, 123, 1, 'Prothrapur'),
(5, 123, 2, 'Vishakhapatnam'),
(6, 123, 2, 'Vijaywada'),
(7, 123, 2, 'Guntur'),
(8, 123, 2, 'Nellore'),
(9, 123, 2, 'Kurnool'),
(10, 123, 2, 'Rajahmundry'),
(11, 123, 2, 'Tirupati'),
(12, 123, 2, 'Kakinada'),
(13, 123, 2, 'Kadapa'),
(14, 123, 2, 'Anantapur'),
(15, 123, 3, 'Aalo'),
(16, 123, 3, 'Itanagar'),
(17, 123, 3, 'Naharlagun'),
(18, 123, 3, 'Pasighat'),
(19, 123, 4, 'Guwahati'),
(20, 123, 4, 'Dibrugarh'),
(21, 123, 4, 'Jorhat'),
(22, 123, 4, 'Nagaon'),
(23, 123, 4, 'Tinsukia'),
(24, 123, 4, 'Tezpur'),
(25, 123, 4, 'Bongaigaon'),
(26, 123, 4, 'Karimganj'),
(27, 123, 4, 'Dhubri'),
(28, 123, 4, 'Diphu'),
(29, 123, 4, 'Silchar'),
(30, 123, 5, 'Patna'),
(31, 123, 5, 'Gaya'),
(32, 123, 5, 'Bhagalpur'),
(33, 123, 5, 'Muzzaffarpur'),
(34, 123, 5, 'Purnia'),
(35, 123, 5, 'Darbhanga'),
(36, 123, 5, 'Ara'),
(37, 123, 5, 'Begusarai'),
(38, 123, 5, 'Katihar'),
(39, 123, 6, 'Chandigarh'),
(40, 123, 7, 'Raipur'),
(41, 123, 7, 'Bhilai'),
(42, 123, 7, 'Bilaspur'),
(43, 123, 7, 'Korba'),
(44, 123, 7, 'Raj Nandgaon'),
(45, 123, 7, 'Raigarh'),
(46, 123, 7, 'Jagdalpur'),
(47, 123, 7, 'Ambikapur'),
(48, 123, 7, 'Dhamtari'),
(49, 123, 8, 'Dadhel'),
(50, 123, 8, 'Daman'),
(51, 123, 8, 'Diu'),
(52, 123, 8, 'Kachigam'),
(53, 123, 9, 'Delhi'),
(54, 123, 9, 'Jaffarpur Kalan'),
(55, 123, 9, 'Qutabgarh'),
(56, 123, 9, 'Ujwa'),
(57, 123, 10, 'Panaji'),
(58, 123, 10, 'Madgaon'),
(59, 123, 10, 'Mormugao'),
(60, 123, 11, 'Ahmadabad'),
(61, 123, 11, 'Surat'),
(62, 123, 11, 'Vadodara'),
(63, 123, 11, 'Rajkot'),
(64, 123, 11, 'Bhavnagar'),
(65, 123, 11, 'Jamnagar'),
(66, 123, 11, 'Junagadh'),
(67, 123, 11, 'Anand'),
(68, 123, 11, 'Navsari'),
(69, 123, 11, 'Surendranagar'),
(70, 123, 11, 'Morvi'),
(71, 123, 12, 'Faridabad'),
(72, 123, 12, 'Gurgaon'),
(73, 123, 12, 'Panipat'),
(74, 123, 12, 'Yamunanagar'),
(75, 123, 12, 'Rohtak'),
(76, 123, 12, 'Hisar'),
(77, 123, 12, 'Karnal'),
(78, 123, 12, 'Sonipat'),
(79, 123, 12, 'Panchkula'),
(80, 123, 12, 'Ambala Sadar'),
(81, 123, 13, 'Baddi'),
(82, 123, 13, 'Chamba'),
(83, 123, 13, 'Dharmsala'),
(84, 123, 13, 'Kullu'),
(85, 123, 13, 'Mandi'),
(86, 123, 13, 'Nahan'),
(87, 123, 13, 'Paonta Sahib'),
(88, 123, 13, 'Shimla'),
(89, 123, 13, 'Solan'),
(90, 123, 13, 'Sundarnagar'),
(91, 123, 14, 'Srinagar'),
(92, 123, 14, 'Jammu'),
(93, 123, 14, 'Anantnag'),
(94, 123, 14, 'Udhampur'),
(95, 123, 14, 'Baramula'),
(96, 123, 14, 'Sopore'),
(97, 123, 14, 'Kathua'),
(98, 123, 14, 'Bandipura'),
(99, 123, 14, 'Leh'),
(100, 123, 15, 'Jamshedpur'),
(101, 123, 15, 'Dhanbad'),
(102, 123, 15, 'Ranchi'),
(103, 123, 15, 'Bokaro Steel City'),
(104, 123, 15, 'Deogarh'),
(105, 123, 15, 'Phusro'),
(106, 123, 15, 'Hazanbag'),
(107, 123, 15, 'Giridih'),
(108, 123, 15, 'Ramgarh Cantonment'),
(109, 123, 15, 'Medininagar'),
(110, 123, 15, 'Chirkunda'),
(111, 123, 16, 'Bengaluru'),
(112, 123, 16, 'Mysore'),
(113, 123, 16, 'Hubli-Dharwar'),
(114, 123, 16, 'Mangalore'),
(115, 123, 16, 'Belgaum'),
(116, 123, 16, 'Gulbarga'),
(117, 123, 16, 'Davanagere'),
(118, 123, 16, 'Bellary'),
(119, 123, 16, 'Bijapur'),
(120, 123, 16, 'Shimoga'),
(121, 123, 16, 'Tumkur'),
(122, 123, 17, 'Kochi'),
(123, 123, 17, 'Kozikode'),
(124, 123, 17, 'Thrissur'),
(125, 123, 17, 'Malappuram'),
(126, 123, 17, 'Thiruvananthapuram'),
(127, 123, 17, 'Kannur'),
(128, 123, 17, 'Kollam'),
(129, 123, 17, 'Cherthala'),
(130, 123, 17, 'Kayamkulam'),
(131, 123, 17, 'Kottayam'),
(132, 123, 18, 'Amini'),
(133, 123, 18, 'Andrott'),
(134, 123, 18, 'Kavaratti'),
(135, 123, 18, 'Minicoy'),
(136, 123, 19, 'Indore'),
(137, 123, 19, 'Bhopal'),
(138, 123, 19, 'Jabalpur'),
(139, 123, 19, 'Gwalior'),
(140, 123, 19, 'Ujjain'),
(141, 123, 19, 'Sagar'),
(142, 123, 19, 'Dewas'),
(143, 123, 19, 'Satna'),
(144, 123, 19, 'Ratlam'),
(145, 123, 19, 'Rewa'),
(146, 123, 20, 'Mumbai'),
(147, 123, 20, 'Pune'),
(148, 123, 20, 'Nagpur'),
(149, 123, 20, 'Nashik'),
(150, 123, 20, 'Vasai-Virar'),
(151, 123, 20, 'Aurangabad'),
(152, 123, 20, 'Solapur'),
(153, 123, 20, 'Bhiwandi'),
(154, 123, 20, 'Amravati'),
(155, 123, 21, 'Imphal'),
(156, 123, 21, 'Kakching'),
(157, 123, 21, 'Mayang Imphal'),
(158, 123, 21, 'Thoubal'),
(159, 123, 21, 'Ukhrul'),
(160, 123, 22, 'Jowai'),
(161, 123, 22, 'Nongstoin'),
(162, 123, 22, 'Shillong'),
(163, 123, 22, 'Tura'),
(164, 123, 22, 'Williamnagar'),
(165, 123, 23, 'Aizwal'),
(166, 123, 23, 'Champhai'),
(167, 123, 23, 'Kolosib'),
(168, 123, 23, 'Lawngtlai'),
(169, 123, 23, 'Lunglei'),
(170, 123, 23, 'Saiha'),
(171, 123, 23, 'Serchhip'),
(172, 123, 24, 'Chumukedima'),
(173, 123, 24, 'Dimapur'),
(174, 123, 24, 'Kohima'),
(175, 123, 24, 'Mokokchung'),
(176, 123, 24, 'Mon'),
(177, 123, 24, 'Tuensang'),
(178, 123, 24, 'Wokha'),
(179, 123, 24, 'Zunheboto'),
(180, 123, 25, 'Bhubaneswar'),
(181, 123, 25, 'Cuttak'),
(182, 123, 25, 'Raurkela'),
(183, 123, 25, 'Brahmapur'),
(184, 123, 25, 'Sambalpur'),
(185, 123, 25, 'Puri'),
(186, 123, 25, 'Baleshwar'),
(187, 123, 25, 'Bhadrak'),
(188, 123, 25, 'Baripada'),
(189, 123, 26, 'Karaikal'),
(190, 123, 26, 'Mahe'),
(191, 123, 26, 'Pondicherry'),
(192, 123, 26, 'Yanam'),
(193, 123, 27, 'Ludhiana'),
(194, 123, 27, 'Amritsar'),
(195, 123, 27, 'Jalandhar'),
(196, 123, 27, 'Patiala'),
(197, 123, 27, 'Bathinda'),
(198, 123, 27, 'S.A.S. Nagar'),
(199, 123, 27, 'Hoshiarpur'),
(200, 123, 27, 'Moga'),
(201, 123, 27, 'Pathankot'),
(202, 123, 27, 'Batala'),
(203, 123, 28, 'Jaipur'),
(204, 123, 28, 'Jodhpur'),
(205, 123, 28, 'Kota'),
(206, 123, 28, 'Bikaner'),
(207, 123, 28, 'Ajmer'),
(208, 123, 28, 'Udaipur'),
(209, 123, 28, 'Bhilwara'),
(210, 123, 28, 'Alwar'),
(211, 123, 28, 'Bharatpur'),
(212, 123, 29, 'Gangtok'),
(213, 123, 29, 'Jorethang'),
(214, 123, 29, 'Namchi'),
(215, 123, 29, 'Rangpo'),
(216, 123, 30, 'Chennai'),
(217, 123, 30, 'Coimbatore'),
(218, 123, 30, 'Madurai'),
(219, 123, 30, 'Tiruchirappalli'),
(220, 123, 30, 'Tiruppur'),
(221, 123, 30, 'Salem'),
(222, 123, 30, 'Erode'),
(223, 123, 30, 'Tirunelveli'),
(224, 123, 30, 'Vellore'),
(225, 123, 30, 'Thoothukkudi'),
(226, 123, 31, 'Hyderabad'),
(227, 123, 31, 'Warangal'),
(228, 123, 31, 'Nizamabad'),
(229, 123, 31, 'Karimnagar'),
(230, 123, 31, 'Khammam'),
(231, 123, 31, 'Ramagundam'),
(232, 123, 31, 'Mahbubnagar'),
(233, 123, 31, 'Mancherial'),
(234, 123, 31, 'Nalgonda'),
(235, 123, 31, 'Adilabad'),
(236, 123, 32, 'Agartala'),
(237, 123, 32, 'Belonia'),
(238, 123, 32, 'Bishalgarh'),
(239, 123, 32, 'Dharmanagar'),
(240, 123, 32, 'Kailashahar'),
(241, 123, 32, 'Teliamura'),
(242, 123, 32, 'Udaipur'),
(243, 123, 33, 'Kanpur'),
(244, 123, 33, 'Lucknow'),
(245, 123, 33, 'Ghaziabad'),
(246, 123, 33, 'Agra'),
(247, 123, 33, 'Varanasi'),
(248, 123, 33, 'Meerut'),
(249, 123, 33, 'Allahabad'),
(250, 123, 33, 'Bareilly'),
(251, 123, 33, 'Aligarh'),
(252, 123, 33, 'Moradabad'),
(253, 123, 34, 'Dehra Dun'),
(254, 123, 34, 'Hardwar'),
(255, 123, 34, 'Roorkee'),
(256, 123, 34, 'Haldwani'),
(257, 123, 34, 'Rudrapur'),
(258, 123, 34, 'Kashipur'),
(259, 123, 34, 'Rishikesh'),
(260, 123, 34, 'Pithoragarh'),
(261, 123, 34, 'Ramnagar'),
(262, 123, 34, 'Kichha'),
(263, 123, 34, 'Manglaur'),
(264, 123, 34, 'Jaspur'),
(265, 123, 35, 'Kolkata'),
(266, 123, 35, 'Asansol'),
(267, 123, 35, 'Shiliguri'),
(268, 123, 35, 'Durgapur'),
(269, 123, 35, 'Bardhaman'),
(270, 123, 35, 'Ingraj Bazar'),
(271, 123, 35, 'Bahrampur'),
(272, 123, 35, 'Habra'),
(273, 123, 35, 'Kharagpur'),
(274, 123, 35, 'Santipur');

-- --------------------------------------------------------

--
-- Table structure for table `ci_sessions`
--

CREATE TABLE IF NOT EXISTS `ci_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `compete`
--

CREATE TABLE IF NOT EXISTS `compete` (
  `compid` int(11) NOT NULL,
  `name` text,
  `descr` text,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `judge` text,
  `prize` text,
  `category` int(11) DEFAULT NULL,
  `organizer1` varchar(100) DEFAULT NULL,
  `organizer2` varchar(100) DEFAULT NULL,
  `organizer3` varchar(100) DEFAULT NULL,
  `organizer4` varchar(100) DEFAULT NULL,
  `organizer5` varchar(100) DEFAULT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `o1` char(2) DEFAULT NULL,
  `o2` char(2) DEFAULT NULL,
  `o3` char(2) DEFAULT NULL,
  `o4` char(2) DEFAULT NULL,
  `o5` char(2) DEFAULT NULL,
  `sub_type` char(2) DEFAULT NULL,
  `entry_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `compete`
--

INSERT INTO `compete` (`compid`, `name`, `descr`, `start_date`, `end_date`, `judge`, `prize`, `category`, `organizer1`, `organizer2`, `organizer3`, `organizer4`, `organizer5`, `start_time`, `end_time`, `o1`, `o2`, `o3`, `o4`, `o5`, `sub_type`, `entry_time`) VALUES
(1, 'lksn', 'slkn', '2015-09-01', '2015-10-02', 'sihd', 'swxn', 3, 'saxenashubham248@gmail.com', '', '', '', '', '00:00:01', '12:59:59', 'A', 'A', 'A', 'A', 'A', 'V', '2015-10-02 06:07:24');

-- --------------------------------------------------------

--
-- Table structure for table `country`
--

CREATE TABLE IF NOT EXISTS `country` (
  `cid` int(11) NOT NULL,
  `cname` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `country`
--

INSERT INTO `country` (`cid`, `cname`) VALUES
(1, 'Afghanistan'),
(2, 'Albania'),
(3, 'Algeria'),
(4, 'Andorra'),
(5, 'Angola'),
(6, 'Antigua and Barbuda'),
(7, 'Argentina'),
(8, 'Armenia'),
(9, 'Aruba'),
(10, 'Australia'),
(11, 'Austria'),
(12, 'Azerbaijan'),
(13, 'Bahamas'),
(14, 'Bahrain'),
(15, 'Bangladesh'),
(16, 'Barbados'),
(17, 'Belarus'),
(18, 'Belgium'),
(19, 'Belize'),
(20, 'Benin'),
(21, 'Bhutan'),
(22, 'Bolivia'),
(23, 'Bosnia and Herzegovina'),
(24, 'Botswana'),
(25, 'Brazil'),
(26, 'Brunei'),
(27, 'Bulgaria'),
(28, 'Burkina Faso'),
(29, 'Burma'),
(30, 'Burundi'),
(31, 'Cambodia'),
(32, 'Cameroon'),
(33, 'Canada'),
(34, 'Cape Verde'),
(35, 'Central African Republic'),
(36, 'Chad'),
(37, 'Chile'),
(38, 'China'),
(39, 'Colombia'),
(40, 'Comoros'),
(41, 'Congo'),
(42, 'Costa Rica'),
(43, 'Cote dlvoire'),
(44, 'Croatia'),
(45, 'Cuba'),
(46, 'Curacao'),
(47, 'Cyprus'),
(48, 'Czech Republic'),
(49, 'Denmark'),
(50, 'Djibouti'),
(51, 'Dominica'),
(52, 'Dominican Republic'),
(53, 'East Timor'),
(54, 'Equador'),
(55, 'Egypt'),
(56, 'El Salvador'),
(57, 'Equatorial Guinea'),
(58, 'Eritrea'),
(59, 'Estonia'),
(60, 'Ethiopia'),
(61, 'Fiji'),
(62, 'Finland'),
(63, 'France'),
(64, 'Gabon'),
(65, 'Gambia'),
(66, 'Georgia'),
(67, 'Germany'),
(68, 'Ghana'),
(69, 'Greece'),
(70, 'Grenada'),
(71, 'Guatemala'),
(72, 'Guinea'),
(73, 'Guinea-Bissau'),
(74, 'Guyana'),
(75, 'Haiti'),
(76, 'Holy See'),
(77, 'Honduras'),
(78, 'Hong Kong'),
(79, 'Hungary'),
(80, 'Iceland'),
(81, 'India'),
(82, 'Indonesia'),
(83, 'Iran'),
(84, 'Iraq'),
(85, 'Ireland'),
(86, 'Israel'),
(87, 'Italy'),
(88, 'Jamaica'),
(89, 'Japan'),
(90, 'Jordan'),
(91, 'Kazakhstan'),
(92, 'Kenya'),
(93, 'Kiribati'),
(94, 'Kosovo'),
(95, 'Kuwait'),
(96, 'Kyrgyzstan'),
(97, 'Laos'),
(98, 'Latvia'),
(99, 'Lebanon'),
(100, 'Lesotho'),
(101, 'Liberia'),
(102, 'Libya'),
(103, 'Liechtenstein'),
(104, 'Lithuania'),
(105, 'Luxembourg'),
(106, 'Macau'),
(107, 'Macedonia'),
(108, 'Madagascar'),
(109, 'Malawi'),
(110, 'Malaysia'),
(111, 'Maldives'),
(112, 'Mali'),
(113, 'Malta'),
(114, 'Marshall Islands'),
(115, 'Mauritius'),
(116, 'Mexico'),
(117, 'Micronesia'),
(118, 'Moldova'),
(119, 'Monaco'),
(120, 'Mongolia'),
(121, 'Montengro'),
(122, 'Morocco'),
(123, 'Mozambique'),
(124, 'Namibia'),
(125, 'Nauru'),
(126, 'Nepal'),
(127, 'Netherlands'),
(128, 'New Zealand'),
(129, 'Nicaragua'),
(130, 'Niger'),
(131, 'Nigeria'),
(132, 'North Korea'),
(133, 'Norway'),
(134, 'Oman'),
(135, 'Pakistan'),
(136, 'Palau'),
(137, 'Palestinian Territories'),
(138, 'Panama'),
(139, 'Papua New Guinea'),
(140, 'Paraguay'),
(141, 'Peru'),
(142, 'Philippines'),
(143, 'Poland'),
(144, 'Portugal'),
(145, 'Qatar'),
(146, 'Romania'),
(147, 'Russia'),
(148, 'Rwanda'),
(149, 'Saint Kitts and Nevis'),
(150, 'Saint Lucia'),
(151, 'Saint Vincent and the Grenadines'),
(152, 'Samoa '),
(153, 'San Marino'),
(154, 'Sao Tome and Principe'),
(155, 'Saudi Arabia '),
(156, 'Senegal'),
(157, 'Serbia '),
(158, 'Seychelles '),
(159, 'Sierra Leone '),
(160, 'Singapore '),
(161, 'Sint Maarten '),
(162, 'Slovekia '),
(163, 'Slovenia '),
(164, 'Solomon Islands '),
(165, 'Somalia '),
(166, 'South Africa '),
(167, 'South Korea '),
(168, 'South Sudan '),
(169, 'Spain '),
(170, 'Sri Lanka '),
(171, 'Sudan '),
(172, 'Suriname '),
(173, 'Swaziland '),
(174, 'Sweden '),
(175, 'Switzerland '),
(176, 'Syria '),
(177, 'Taiwan '),
(178, 'Tajikistan '),
(179, 'Tanzania '),
(180, 'Thailand '),
(181, 'Timor-Leste '),
(182, 'Togo '),
(183, 'Tonga'),
(184, 'Trinidad and Tobago '),
(185, 'Tunisia '),
(186, 'Turkey '),
(187, 'Turkmenistan '),
(188, 'Tuvalu '),
(189, 'Uganda '),
(190, 'Ukraine '),
(191, 'United Arab Emirates '),
(192, 'United Kingdom '),
(193, 'Uruguay '),
(194, 'Uzbekistan '),
(195, 'Vanuatu '),
(196, 'Venezuela '),
(197, 'Vietnam '),
(198, 'Yemen '),
(199, 'Zambia '),
(200, 'Zimbabwe ');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE IF NOT EXISTS `course` (
  `courseid` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `insti` text,
  `pic` varchar(300) DEFAULT NULL,
  `content` text,
  `nolec` int(11) DEFAULT NULL,
  `tutor` text,
  `nostu` int(11) DEFAULT NULL,
  `sdate` date DEFAULT NULL,
  `edate` date DEFAULT NULL,
  `s1` int(11) DEFAULT NULL,
  `s2` int(11) DEFAULT NULL,
  `skill` varchar(100) DEFAULT NULL,
  `website` varchar(100) DEFAULT NULL,
  `oc` int(11) DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `month` int(11) DEFAULT NULL,
  `day` int(11) DEFAULT NULL,
  `new_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`courseid`, `name`, `insti`, `pic`, `content`, `nolec`, `tutor`, `nostu`, `sdate`, `edate`, `s1`, `s2`, `skill`, `website`, `oc`, `year`, `month`, `day`, `new_time`) VALUES
(1, 'bhoo', 'foo', '1.png', 'blaah', 5, 'hui', 150, '2015-08-31', '2015-08-31', 2, 5, '1', 'hhuuu.bhu', 1, 0, 0, 20, '2015-09-21 17:33:07'),
(2, 'ghyy', 'aafoo', '2.png', 'bleeh', 8, 'huisss', 77, '2015-08-05', '2015-08-12', 3, 2, '1', 'hhuuu.bhu', 0, 0, 0, 7, '2015-09-21 17:33:07');

-- --------------------------------------------------------

--
-- Table structure for table `db_products`
--

CREATE TABLE IF NOT EXISTS `db_products` (
`id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `description` varchar(2000) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `db_products`
--

INSERT INTO `db_products` (`id`, `name`, `price`, `quantity`, `description`) VALUES
(1, 'earing', 255, 5, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publis'),
(2, 'gold', 123, 23, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publis'),
(3, 'bangles', 268, 3, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publis'),
(4, 'chain', 567, 32, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publis'),
(5, 'necklace', 3287, 56, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publis'),
(6, 'diamond', 32, 32, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publis'),
(7, 'ruby', 3459, 56, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publis'),
(8, 'gold ring', 3459, 56, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publis'),
(9, 'diamond ring', 3459, 56, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publis'),
(10, 'nose-pin', 3459, 56, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publis');

-- --------------------------------------------------------

--
-- Table structure for table `description`
--

CREATE TABLE IF NOT EXISTS `description` (
  `userid` varchar(100) NOT NULL,
  `about` text,
  `status` varchar(200) DEFAULT NULL,
  `experience` text,
  `lang` text,
  `age` int(11) DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `hobby` text,
  `curplace` text,
  `home` text,
  `qualification` text,
  `music` text,
  `movies` text,
  `sports` text,
  `dance` text,
  `bdate` date DEFAULT NULL,
  `relation` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `description`
--

INSERT INTO `description` (`userid`, `about`, `status`, `experience`, `lang`, `age`, `gender`, `hobby`, `curplace`, `home`, `qualification`, `music`, `movies`, `sports`, `dance`, `bdate`, `relation`) VALUES
('arpita1995jaipur@gmail.com', NULL, NULL, NULL, NULL, 0, 'female', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1980-01-01', NULL),
('avaneesh.nitw@gmail.com', NULL, NULL, NULL, NULL, 0, 'Male', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1995-05-23', NULL),
('ayushi.nayak@gmail.com', NULL, NULL, NULL, NULL, 0, 'female', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1980-01-01', NULL),
('ivy.maji@gmail.com', NULL, NULL, NULL, NULL, 0, 'female', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1980-01-01', NULL),
('lakshit.nagpal@gmail.com', NULL, NULL, NULL, NULL, 0, 'female', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1980-01-01', NULL),
('manish.mandal@gmail.com', NULL, NULL, NULL, NULL, 0, 'female', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1980-01-01', NULL),
('sanashubham248@gmail.com', NULL, NULL, NULL, NULL, 0, 'Male', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '3333-03-31', NULL),
('saxenashkubham248@gmail.com', 'efwefewfew\r\new\r\nfewfew\r\nfwefwe\r\nf\r\newfewfwefewfe\r\nwfew\r\nfew\r\nfewf\r\nwef\r\nwef\r\nwef', '', 'fefwef\r\n\r\nwe\r\nfwe\r\nfewfe\r\nwfew\r\nf', '', 33, 'Male', 'wefewf\r\nwefwef\r\nwef\r\nwefew\r\nfewf', '', '', 'ewfewf\r\newfew\r\nfewf\r\nwef\r\nw', '', '', '', '', '3333-11-11', 'relation'),
('saxenashubham248@gmail.com', 's,dkihlwd.kn', '', 'lwhdlkh', 'Bengali ', 22, 'Male', 'wlkbdkl,', 'ald;', 'lakdn', 'wkb', 'Easy Listening ', 'Horror ', 'Badminton ', 'Bollywood ', '1093-02-22', 'relation'),
('saxenasswati48@gmail.com', NULL, NULL, NULL, NULL, 0, 'Female', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1996-04-14', NULL),
('shubhamsaxena248@gmail.com', NULL, NULL, NULL, NULL, 0, 'female', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1980-01-01', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `entity`
--

CREATE TABLE IF NOT EXISTS `entity` (
  `entityid` int(11) NOT NULL,
  `type` char(1) DEFAULT NULL,
  `userid` varchar(100) DEFAULT NULL,
  `content` text,
  `rating` int(11) DEFAULT NULL,
  `likes` int(11) DEFAULT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` char(5) DEFAULT NULL,
  `c1` int(11) DEFAULT NULL,
  `c2` int(11) DEFAULT NULL,
  `c3` int(11) DEFAULT NULL,
  `c4` int(11) DEFAULT NULL,
  `c5` int(11) DEFAULT NULL,
  `c6` int(11) DEFAULT NULL,
  `caption` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `entity`
--

INSERT INTO `entity` (`entityid`, `type`, `userid`, `content`, `rating`, `likes`, `time`, `deleted`, `c1`, `c2`, `c3`, `c4`, `c5`, `c6`, `caption`) VALUES
(1, 'I', 'arpita1995jaipur@gmail.com', 'arpita1995jaipur@gmail.com1.jpg', 0, 1, '2015-10-06 16:54:52', 'no', 0, 0, 0, 0, 1, 0, ''),
(2, 'I', 'arpita1995jaipur@gmail.com', 'arpita1995jaipur@gmail.com1.jpg', 0, 10, '2015-10-06 16:58:27', 'no', 1, 1, 1, 1, 0, 0, ''),
(3, 'I', 'arpita1995jaipur@gmail.com', 'arpita1995jaipur@gmail.com1.png', 0, 12, '2015-09-22 01:20:50', 'no', 1, 0, 1, 0, 1, 1, ''),
(4, 'I', 'arpita1995jaipur@gmail.com', 'arpita1995jaipur@gmail.com2.png', 0, 22, '2015-10-06 21:27:36', 'no', 1, 0, 1, 1, 1, 1, ''),
(5, 'V', 'arpita1995jaipur@gmail.com', 'https://www.youtube.com/embed/ROyRZ9S24qE', 0, 20, '2015-09-22 01:20:50', 'no', 1, 1, 1, 0, 0, 0, ''),
(6, 'I', 'arpita1995jaipur@gmail.com', 'arpita1995jaipur@gmail.com5.png', 0, 60, '2015-09-22 01:20:50', 'no', 0, 1, 0, 1, 1, 0, ''),
(7, 'P', 'arpita1995jaipur@gmail.com', 'pata\r\n', 0, 21, '2015-10-11 05:57:14', 'no', 1, 0, 1, 1, 0, 0, ''),
(8, 'I', 'arpita1995jaipur@gmail.com', 'arpita1995jaipur@gmail.com3.jpg', 0, 33, '2015-09-22 01:34:44', 'no', 1, 0, 1, 0, 1, 0, ''),
(9, 'I', 'arpita1995jaipur@gmail.com', 'arpita1995jaipur@gmail.com2.png', 0, 0, '2015-09-22 01:15:49', 'no', 0, 0, 0, 0, 0, 0, ''),
(10, 'P', 'arpita1995jaipur@gmail.com', 'wfdwq', 0, 0, '2015-08-11 18:14:16', 'no', 0, 0, 0, 0, 0, 0, ''),
(11, 'P', 'arpita1995jaipur@gmail.com', 'rtyrdtrdt', 0, 3, '2015-10-11 18:28:21', 'no', 0, 0, 0, 0, 0, 0, ''),
(12, 'I', 'arpita1995jaipur@gmail.com', 'arpita1995jaipur@gmail.comPicture1.jpg', 0, 0, '2015-08-13 18:08:05', 'no', 0, 0, 1, 0, 0, 0, ''),
(13, 'P', 'arpita1995jaipur@gmail.com', 'dsgfdxvgdvdsgbcv', 0, 2, '2015-10-11 05:57:10', 'no', 0, 0, 0, 0, 0, 0, ''),
(14, 'I', 'arpita1995jaipur@gmail.com', 'arpita1995jaipur@gmail.comgalla.png', 0, 0, '2015-08-16 08:40:41', 'no', 0, 0, 0, 0, 0, 0, ''),
(15, 'I', 'arpita1995jaipur@gmail.com', 'arpita1995jaipur@gmail.comScreenshot (87).png', 0, 0, '2015-08-16 08:40:42', 'no', 0, 0, 0, 0, 0, 0, ''),
(16, 'I', 'arpita1995jaipur@gmail.com', 'arpita1995jaipur@gmail.comScreenshot (88) - Copy.png', 0, 0, '2015-08-16 08:40:42', 'no', 0, 0, 0, 0, 0, 0, ''),
(17, 'I', 'arpita1995jaipur@gmail.com', 'arpita1995jaipur@gmail.comScreenshot (90) - Copy.png', 0, 0, '2015-08-16 08:45:51', 'no', 0, 0, 0, 1, 0, 0, ''),
(18, 'I', 'saxenashubham248@gmail.com', 'saxenashubham248@gmail.com3.jpg', 0, 0, '2015-09-22 01:15:49', 'no', 1, 0, 0, 0, 0, 0, ''),
(19, 'P', 'saxenashubham248@gmail.com', 'uigiugiug', 0, 0, '2015-10-05 07:33:08', 'yes', 0, 0, 0, 0, 0, 0, ''),
(20, 'I', 'saxenashubham248@gmail.com', 'saxenashubham248@gmail.com21.jpg', 0, 0, '2015-09-22 01:15:49', 'no', 0, 0, 0, 0, 0, 0, ''),
(21, 'P', 'saxenashubham248@gmail.com', 'kbjkjn', 0, 0, '2015-09-22 01:15:49', 'no', 0, 0, 0, 0, 0, 0, ''),
(22, 'P', 'saxenashubham248@gmail.com', 'sdcschvhxvcdyvgcusygduvc y \r\n\r\n\r\n', 0, 0, '2015-09-06 17:41:44', 'no', 0, 0, 0, 0, 0, 0, ''),
(23, 'P', 'saxenashubham248@gmail.com', 'gbhfgbgfb', 0, 0, '2015-09-06 17:41:53', 'no', 0, 0, 0, 0, 0, 0, ''),
(24, 'P', 'saxenashubham248@gmail.com', 'ghgfh', 0, 0, '2015-09-06 17:41:57', 'no', 0, 0, 0, 0, 0, 0, ''),
(25, 'P', 'saxenashubham248@gmail.com', 'ghhgfhfgh', 0, 0, '2015-09-22 01:15:49', 'no', 0, 0, 0, 0, 0, 0, ''),
(26, 'I', 'saxenashubham248@gmail.com', 'saxenashubham248@gmail.com1.png', 0, 0, '2015-09-07 17:28:57', 'no', 0, 0, 0, 0, 0, 0, ''),
(27, 'I', 'saxenashubham248@gmail.com', 'saxenashubham248@gmail.com2.png', 0, 0, '2015-09-07 17:28:58', 'no', 0, 0, 0, 0, 0, 0, ''),
(28, 'I', 'saxenashubham248@gmail.com', 'saxenashubham248@gmail.com3.png', 0, 0, '2015-09-07 17:28:58', 'no', 0, 0, 0, 0, 0, 0, ''),
(29, 'I', 'saxenashubham248@gmail.com', 'saxenashubham248@gmail.com4.png', 0, 0, '2015-09-07 17:28:58', 'no', 0, 0, 0, 0, 0, 0, ''),
(30, 'I', 'saxenashubham248@gmail.com', 'saxenashubham248@gmail.com5.png', 0, 0, '2015-09-07 17:28:58', 'no', 0, 0, 0, 0, 0, 0, ''),
(31, 'I', 'saxenashubham248@gmail.com', 'saxenashubham248@gmail.com8.png', 0, 0, '2015-09-16 06:34:55', 'no', 0, 1, 0, 0, 0, 0, ''),
(32, 'V', 'saxenashubham248@gmail.com', 'https://www.youtube.com/embed/nCD2hj6zJEc', 0, 0, '2015-09-07 18:15:23', 'no', 0, 0, 0, 0, 0, 0, ''),
(33, 'V', 'saxenashubham248@gmail.com', 'https://www.youtube.com/embed/nCD2hj6zJEc', 0, 0, '2015-09-07 18:16:06', 'no', 0, 0, 0, 0, 0, 0, ''),
(34, 'P', 'saxenashubham248@gmail.com', ';lsml;mlm', 0, 0, '2015-10-05 17:58:21', 'no', 0, 0, 0, 0, 0, 0, ''),
(35, 'P', 'saxenashubham248@gmail.com', 'm,d', 0, 0, '2015-10-05 21:14:08', 'no', 0, 0, 0, 0, 0, 0, ''),
(36, 'I', 'saxenashubham248@gmail.com', 'saxenashubham248@gmail.com5.png', 0, 0, '2015-10-10 19:59:49', 'yes', 0, 0, 0, 0, 0, 0, ''),
(37, 'P', 'saxenashubham248@gmail.com', 'ofjeo;fj', 0, 0, '2015-10-05 21:20:04', 'no', 0, 0, 0, 0, 0, 0, ''),
(38, 'P', 'saxenashubham248@gmail.com', 'aefijh', 0, 0, '2015-10-05 21:22:44', 'no', 0, 0, 0, 0, 0, 0, ''),
(39, 'P', 'saxenashubham248@gmail.com', 'aefijh', 0, 0, '2015-10-05 21:23:23', 'no', 0, 0, 0, 0, 0, 0, ''),
(40, 'P', 'saxenashubham248@gmail.com', 'aefijh', 0, 0, '2015-10-05 21:24:50', 'no', 0, 0, 0, 0, 0, 0, ''),
(41, 'I', 'saxenashubham248@gmail.com', 'saxenashubham248@gmail.com81.png', 0, 0, '2015-10-06 11:09:22', 'no', 0, 0, 0, 0, 0, 0, ''),
(42, 'P', 'saxenashubham248@gmail.com', 'asojdlasojdfsodljfposjfojsdfpojspofjrpofjpodsjposdjfpodsjvolgdfjgvpoasojdlasojdfsodljfposjfojsdfpojs', 0, 1, '2015-10-08 07:20:50', 'yes', 0, 0, 0, 1, 1, 1, ''),
(43, 'P', 'saxenashubham248@gmail.com', 'klsndflknsdlknclk{\r\n    font-size: 20px;\r\n    width: 500px;\r\n    height: auto;\r\n    /* min-height: 2', 0, 0, '2015-10-08 07:20:52', 'yes', 0, 0, 0, 0, 0, 0, ''),
(44, 'P', 'saxenashubham248@gmail.com', 'oihoihoihsadoiha \r\nadilahwdoihas\r\nasa\r\ndsae\r\nda\r\ned\r\need\r\ned\r\nwe\r\ndwe\r\nd\r\newd\r\nsd\r\nfsd\r\nsd\r\nfsd\r\nf\r\ndsf\r\nds\r\nsd\r\ndsd\r\nsd\r\n\r\nds', 0, 0, '2015-10-08 07:20:51', 'yes', 0, 0, 0, 0, 0, 0, ''),
(45, 'P', 'saxenashkubham248@gmail.com', 'wdwd\r\nw\r\ndwq\r\nd', 0, 0, '2015-10-06 19:57:12', 'no', 0, 0, 0, 0, 0, 0, ''),
(46, 'I', 'saxenashkubham248@gmail.com', 'saxenashkubham248@gmail.com1.png', 0, 0, '2015-10-06 19:57:55', 'no', 0, 0, 0, 0, 0, 0, ''),
(47, 'I', 'saxenashkubham248@gmail.com', 'saxenashkubham248@gmail.com2.png', 0, 0, '2015-10-06 19:57:55', 'no', 0, 0, 0, 0, 0, 0, ''),
(48, 'I', 'saxenashkubham248@gmail.com', 'saxenashkubham248@gmail.com3.png', 0, 0, '2015-10-06 19:57:55', 'no', 0, 0, 0, 0, 0, 0, ''),
(49, 'V', 'saxenashkubham248@gmail.com', 'http://gaana.com/artist/ar-rahman-2', 0, 0, '2015-10-06 19:59:16', 'no', 0, 0, 0, 0, 0, 0, ''),
(50, 'P', 'saxenashubham248@gmail.com', 'shhs', 0, 0, '2015-10-08 07:20:49', 'yes', 0, 0, 0, 0, 0, 0, ''),
(51, 'P', 'saxenashubham248@gmail.com', 'edkm', 0, 0, '2015-10-08 07:24:22', 'no', 0, 0, 0, 0, 0, 0, ''),
(52, 'P', 'saxenashubham248@gmail.com', 'edkm', 0, 0, '2015-10-08 07:22:38', 'no', 0, 0, 0, 0, 0, 0, ''),
(53, 'P', 'saxenashubham248@gmail.com', 'kewnkjnwek', 0, 0, '2015-10-10 18:55:13', 'no', 0, 0, 0, 0, 0, 0, ''),
(54, 'P', 'saxenashubham248@gmail.com', 'elkjnlkdn', 0, 0, '2015-10-11 04:13:54', 'no', 0, 0, 0, 0, 0, 0, ''),
(55, 'P', 'saxenashubham248@gmail.com', 'lknlknlk', 0, 1, '2015-10-11 12:35:57', 'no', 1, 0, 0, 0, 0, 0, ''),
(56, 'P', 'saxenashubham248@gmail.com', 'lknlknl,n,,mn,m', 0, 0, '2015-10-11 16:36:11', 'no', 0, 0, 1, 1, 1, 1, ''),
(57, 'P', 'saxenashubham248@gmail.com', 'Suri chutiya', 0, 1, '2015-10-11 12:35:55', 'no', 0, 0, 0, 0, 0, 0, ''),
(58, 'P', 'avaneesh.nitw@gmail.com', 'ouihyoihy', 0, 0, '2015-10-11 12:33:47', 'no', 0, 0, 0, 0, 0, 0, ''),
(59, 'P', 'saxenashubham248@gmail.com', 'ALJSOAJSPOJALJSOAJSPOJALJSOAJSPOJALJSOAJSPOJALJSOAJSPOJALJSOAJSPOJALJSOAJSPOJALJSOAJSPOJALJSOAJSPOJALJSOAJSPOJALJSOAJSPOJALJSOAJSPOJALJSOAJSPOJALJSOAJSPOJALJSOAJSPOJALJSOAJSPOJALJSOAJSPOJALJSOAJSPOJALJSOAJSPOJALJSOAJSPOJALJSOAJSPOJALJSOAJSPOJALJSOAJSPOJALJSOAJSPOJALJSOAJSPOJ\r\n\r\n\r\n\r\n\r\nALJSOAJSPOJ', 0, 0, '2015-10-11 16:36:36', 'no', 0, 0, 0, 0, 0, 0, ''),
(60, 'P', 'saxenashubham248@gmail.com', 'kihdiotrfhseioho', 0, 0, '2015-10-15 17:27:27', 'no', 1, 1, 1, 1, 1, 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `cid` int(11) NOT NULL,
  `userid` varchar(100) NOT NULL,
  `anomy` int(2) NOT NULL,
  `content` text NOT NULL,
  `new_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`cid`, `userid`, `anomy`, `content`, `new_time`) VALUES
(1, 'arpita1995jaipur@gmail.com', 1, 'jhadjbcjshckjscnmciuschkasjmz zbddhiahkjsnx sxhsixhsaxnasx asxisaxksajnxas asxhisanhxikasx asxashxioSIOXSA XASMJXASIXHASOI ASXASIOXHSAIOAS XAS CASCIOSAXSAX ASXjhadjbcjshckjscnmciuschkasjmz zbddhiahkjsnx sxhsixhsaxnasx asxisaxksajnxas asxhisanhxikasx asxashxioSIOXSA XASMJXASIXHASOI ASXASIOXHSAIOAS XAS CASCIOSAXSAX ASXjhadjbcjshckjscnmciuschkasjmz zbddhiahkjsnx sxhsixhsaxnasx asxisaxksajnxas asxhisanhxikasx asxashxioSIOXSA XASMJXASIXHASOI ASXASIOXHSAIOAS XAS CASCIOSAXSAX ASXjhadjbcjshckjscnmciuschkasjmz zbddhiahkjsnx sxhsixhsaxnasx asxisaxksajnxas asxhisanhxikasx asxashxioSIOXSA XASMJXASIXHASOI ASXASIOXHSAIOAS XAS CASCIOSAXSAX ASX', '2015-09-21 23:39:44'),
(1, 'ayushi.nayak@gmail.com', 0, 'whataedhskjscgscscscuschbmnchc hdkjnjkxsmcbscs cscshcksjc mschscns dcsdhcsdncsdchsdcndscsducjknsd c dcsdcihsdcs cdscnjwhataedhskjscgscscscuschbmnchc hdkjnjkxsmcbscs cscshcksjc mschscns dcsdhcsdncsdchsdcndscsducjknsd c dcsdcihsdcs cdscnjwhataedhskjscgscscscuschbmnchc hdkjnjkxsmcbscs cscshcksjc mschscns dcsdhcsdncsdchsdcndscsducjknsd c dcsdcihsdcs cdscnjwhataedhskjscgscscscuschbmnchc hdkjnjkxsmcbscs cscshcksjc mschscns dcsdhcsdncsdchsdcndscsducjknsd c dcsdcihsdcs cdscnj', '2015-09-21 23:39:44');

-- --------------------------------------------------------

--
-- Table structure for table `follow`
--

CREATE TABLE IF NOT EXISTS `follow` (
  `userid` varchar(100) DEFAULT NULL,
  `fid` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `follow`
--

INSERT INTO `follow` (`userid`, `fid`) VALUES
('arpita1995jaipur@gmail.com', 'ivy.maji@gmail.com'),
('ivy.maji@gmail.com', 'arpita1995jaipur@gmail.com'),
('saxenashubham248@gmail.com', 'ivy.maji@gmail.com'),
('saxenashubham248@gmail.com', 'shubhamsaxena248@gmail.com'),
('saxenashubham248@gmail.com', 'shubhamsaxena248@gmail.com'),
('saxenashkubham248@gmail.com', 'saxenashubham248@gmail.com'),
('saxenashkubham248@gmail.com', 'arpita1995jaipur@gmail.com'),
('saxenashkubham248@gmail.com', 'ivy.maji@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE IF NOT EXISTS `gallery` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `artist` varchar(200) NOT NULL,
  `price` int(11) NOT NULL,
  `about` text NOT NULL,
  `sold` int(11) NOT NULL,
  `no_cust` int(11) NOT NULL,
  `uniq` int(11) NOT NULL,
  `content` varchar(500) NOT NULL,
  `pic` varchar(100) NOT NULL,
  `category` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`id`, `name`, `artist`, `price`, `about`, `sold`, `no_cust`, `uniq`, `content`, `pic`, `category`) VALUES
(1, 'Bittu', 'saxenashubham248@gmail.com', 100, 'MAhana', 0, 0, 1, 'BAhut na=mahana', 'Picture1.jpg', 1),
(2, 'Bittu', 'saxenashubham248@gmail.com', 100, 'MAhana', 0, 0, 1, 'BAhut na=mahana', 'Picture1.jpg', 1),
(3, 'Bittu', 'saxenashubham248@gmail.com', 100, 'MAhana', 0, 0, 1, 'BAhut na=mahana', 'Picture1.jpg', 1),
(4, 'Bittu', 'saxenashubham248@gmail.com', 100, 'MAhana', 0, 0, 1, 'BAhut na=mahana', '3401417-42-iron-man-iron-man-hd-8-free-spot-free-download.jpg', 1),
(5, 'Bittu', 'saxenashubham248@gmail.com', 100, 'MAhana', 0, 0, 1, 'BAhut na=mahana', 'galla.png', 1),
(6, 'Bittu', 'saxenashubham248@gmail.com', 100, 'MAhana', 0, 0, 1, 'BAhut na=mahana', '11.JPG', 1),
(7, 'Shubham', 'avaneesh.nitw@gmail.com', 1020, 'WRar', 0, 0, 1, 'ewf', 'WIN_20150313_171341.JPG', 3),
(8, 'Shubham', 'saxenashubham248@gmail.com', 1000, 'Great', 0, 0, 1, 'Loved it', 'shubham.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE IF NOT EXISTS `groups` (
  `gid` int(11) NOT NULL,
  `userid` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`gid`, `userid`) VALUES
(1, 'saxenashubham248@gmail.com'),
(1, 'lakshita.nagpal@gmail.com'),
(1, 'avaneesh.nitw@gmail.com'),
(1, 'ayushi.nayak@gmail.com'),
(1, 'ivy.maji@gmail.com'),
(1, 'manish.mandal@gmail.com'),
(1, 'saxenasswati48@gmail.com'),
(2, 'saxenashubham248@gmail.com'),
(2, 'saxenasswati48@gmail.com'),
(2, 'saxenasswati48@gmail.com'),
(2, 'saxenasswati48@gmail.com'),
(2, 'saxenashubham248@gmail.com'),
(2, 'arpita1995jaipur@gmail.com'),
(2, 'arpita1995jaipur@gmail.com'),
(2, 'ayushi.nayak@gmail.com'),
(2, 'saxenashubham248@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `group_entity`
--

CREATE TABLE IF NOT EXISTS `group_entity` (
  `tid` int(11) NOT NULL,
  `gid` int(11) NOT NULL,
  `userid` varchar(100) NOT NULL,
  `type` char(2) NOT NULL,
  `content` text NOT NULL,
  `likes` int(11) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `group_entity`
--

INSERT INTO `group_entity` (`tid`, `gid`, `userid`, `type`, `content`, `likes`, `time`) VALUES
(1, 1, 'saxenashubham248@gmail.com', 'P', 'oiherfioh', 0, '2015-10-15 12:32:22');

-- --------------------------------------------------------

--
-- Table structure for table `group_likes`
--

CREATE TABLE IF NOT EXISTS `group_likes` (
  `entityid` int(11) NOT NULL,
  `userid` varchar(100) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `lecture`
--

CREATE TABLE IF NOT EXISTS `lecture` (
  `cid` int(11) DEFAULT NULL,
  `vurl` varchar(200) DEFAULT NULL,
  `content` text,
  `lecture_no` int(11) DEFAULT NULL,
  `response` int(11) DEFAULT NULL,
  `type` char(3) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `new_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lecture`
--

INSERT INTO `lecture` (`cid`, `vurl`, `content`, `lecture_no`, `response`, `type`, `name`, `new_time`) VALUES
(1, 'https://www.youtube.com/embed/JSTdArrLaCo', 'beintaah har jeet bhi haardu', 1, 1, 'V', 'bhooaaaa', '2015-09-21 19:21:37'),
(1, 'https://www.youtube.com/embed/Y9N6zdXdz9A', 'https://www.youtube.com/watch?v=Y9N6zdXdz9A', 2, 1, 'V', 'bahi', '2015-09-21 19:36:24');

-- --------------------------------------------------------

--
-- Table structure for table `likes`
--

CREATE TABLE IF NOT EXISTS `likes` (
  `entityid` int(11) DEFAULT NULL,
  `userid` varchar(100) DEFAULT NULL,
  `like_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `type` char(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `likes`
--

INSERT INTO `likes` (`entityid`, `userid`, `like_time`, `type`) VALUES
(1, 'saxenashubham248@gmail.com', '2015-10-06 16:54:51', ''),
(4, 'saxenashubham248@gmail.com', '2015-10-06 17:46:45', ''),
(4, 'saxenashkubham248@gmail.com', '2015-10-06 21:27:36', ''),
(13, 'saxenashkubham248@gmail.com', '2015-10-06 21:35:58', ''),
(42, 'saxenashkubham248@gmail.com', '2015-10-06 21:42:50', '');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
`id` int(11) NOT NULL,
  `username` varchar(20000) NOT NULL,
  `password` varchar(20000) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `username`, `password`) VALUES
(1, 'sachin', 'sachin'),
(2, 'ketki', 'ketki');

-- --------------------------------------------------------

--
-- Table structure for table `temp_user`
--

CREATE TABLE IF NOT EXISTS `temp_user` (
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `temp_user`
--

INSERT INTO `temp_user` (`username`, `password`, `email`, `key`) VALUES
('brother', 'brother', 'brether@bro.com', '309e35553f67acd667a0126a68ef4075'),
('brother', 'brother', 'brether@bro.com', 'fde35132be8c2e0102031f5f7938f324'),
('brother', 'brother', 'brether@bro.com', '309e35553f67acd667a0126a68ef4075'),
('brother', 'brother', 'brether@bro.com', 'fde35132be8c2e0102031f5f7938f324');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
`id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`) VALUES
(1, 'askeme', 'askeme', 'askeme@as.com'),
(2, 'sachin931350', 'nirmala22', 'sachin931350@gmail.com'),
(3, 'brother', 'brother', 'brether@bro.com'),
(4, 'ketki', 'ketki', 'ketki@ketki.com'),
(5, 'sachin', 'sachin', 'sachin@sachin.com'),
(6, 'someone', 'someone', 'someone@google.com'),
(7, 'sakkcjkaj', 'hbdcjhcb', 'dhksbcsjdhbc@sshcbch.cjsh'),
(8, 'shubham', 'shubham', 'shubham@bgvdf.com'),
(9, 'sacjnakjs', 'sachin', 'kjdscskj@jkvkj.com'),
(10, 'sasuke', 'patil', 'sas@sas.com'),
(11, 'sachin8114', 'nirmala22', 'sachin931350@gmail.com'),
(12, 'askeme', 'askeme', 'askeme@as.com'),
(13, 'sachin931350', 'nirmala22', 'sachin931350@gmail.com'),
(14, 'brother', 'brother', 'brether@bro.com'),
(15, 'ketki', 'ketki', 'ketki@ketki.com'),
(16, 'sachin', 'sachin', 'sachin@sachin.com'),
(17, 'someone', 'someone', 'someone@google.com'),
(18, 'sakkcjkaj', 'hbdcjhcb', 'dhksbcsjdhbc@sshcbch.cjsh'),
(19, 'shubham', 'shubham', 'shubham@bgvdf.com');

-- --------------------------------------------------------

--
-- Table structure for table `user_post`
--

CREATE TABLE IF NOT EXISTS `user_post` (
`id` int(11) NOT NULL,
  `user` varchar(255) NOT NULL,
  `description` varchar(20000) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_post`
--

INSERT INTO `user_post` (`id`, `user`, `description`) VALUES
(1, 'sachin', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.'),
(2, 'ketki', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.'),
(3, 'sawhney', 'dcnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnsssssssssjjjjsjjjjjjjjjjjjjajjjjjjjjjjjjjaaaaaa'),
(4, 'saxena', 'dcccccccccccckjecnsjkajnvkjfvkjvjkvjka jkjfa kjfnvjankjn'),
(5, 'rinisha', 'https://www.facebook.com/');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ci_sessions`
--
ALTER TABLE `ci_sessions`
 ADD PRIMARY KEY (`session_id`), ADD KEY `last_activity_idx` (`last_activity`);

--
-- Indexes for table `db_products`
--
ALTER TABLE `db_products`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_post`
--
ALTER TABLE `user_post`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `db_products`
--
ALTER TABLE `db_products`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `user_post`
--
ALTER TABLE `user_post`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
